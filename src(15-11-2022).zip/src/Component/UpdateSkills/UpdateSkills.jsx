import React from "react";
import { Header } from "../Header/Header";
import { UserSkillsUpdate } from "../UserSkillsUpdate/UserSkillsUpdate";
import { UserResumeUpload } from "../UserResumeUpload/UserResumeUpload";
import { UserCertificateUpload } from "../UserCertificateUpload/UserCertificateUpload";

export const UpdateSkills = () => {
 
  return (
    <div>
      <Header />
      <UserSkillsUpdate/>
      <UserResumeUpload/>
      <UserCertificateUpload/>
    </div>
  );
};
